# common helper functions

library(dplyr)
library(lubridate)
library(DBI)
library(RPostgres)
library(tibble)

# auto-detect manual_month from database (latest LFS period + 2 months)
auto_detect_manual_month <- function() {
  tryCatch({
    conn <- DBI::dbConnect(RPostgres::Postgres())
    on.exit(try(DBI::dbDisconnect(conn), silent = TRUE))

    res <- DBI::dbGetQuery(conn, 'SELECT DISTINCT time_period FROM "ons"."labour_market__age_group"')
    if (nrow(res) == 0) return(NULL)

    month_map <- c(jan=1,feb=2,mar=3,apr=4,may=5,jun=6,jul=7,aug=8,sep=9,oct=10,nov=11,dec=12)

    parse_end <- function(label) {
      mons <- regmatches(label, gregexpr("[A-Za-z]{3}", label))[[1]]
      yrs  <- regmatches(label, gregexpr("[0-9]{4}", label))[[1]]
      if (length(mons) < 2 || length(yrs) < 1) return(as.Date(NA))
      end_m <- month_map[tolower(mons[2])]
      yr <- suppressWarnings(as.integer(yrs[1]))
      if (is.na(end_m) || is.na(yr)) return(as.Date(NA))
      as.Date(sprintf("%04d-%02d-01", yr, end_m))
    }

    ends <- as.Date(vapply(res$time_period, parse_end, as.Date(NA)), origin = "1970-01-01")
    if (all(is.na(ends))) return(NULL)

    latest_end <- max(ends, na.rm = TRUE)
    # manual_month = LFS end + 2 months (convention: anchor month of the release)
    anchor <- latest_end %m+% months(2)
    tolower(paste0(format(anchor, "%b"), format(anchor, "%Y")))
  }, error = function(e) {
    warning("auto_detect_manual_month failed: ", e$message, "; using Sys.Date fallback")
    NULL
  })
}

# manual month parsing

parse_manual_month <- function(mm) {
  mm <- tolower(mm)
  mm <- gsub("[[:space:]]+", "", mm)
  
  letters_part <- gsub("[^a-z]", "", mm)
  digits_part <- gsub("[^0-9]", "", mm)
  
  if (nchar(letters_part) < 3 || nchar(digits_part) < 4) {
    stop("manual_month must look like 'oct2025', got: ", mm, call. = FALSE)
  }
  
  mon3 <- substr(letters_part, 1, 3)
  m <- match(mon3, tolower(month.abb))
  yr <- suppressWarnings(as.integer(substr(digits_part, 1, 4)))
  
  if (is.na(m) || is.na(yr)) {
    stop("manual_month must look like 'oct2025', got: ", mm, call. = FALSE)
  }
  
  as.Date(sprintf("%04d-%02d-01", yr, m))
}

# time period format helpers

# convert date to lfs 3-month format: "jul-sep 2025"
make_lfs_label <- function(end_date) {
  start_date <- end_date %m-% months(2)
  sprintf("%s-%s %s",
          format(start_date, "%b"),
          format(end_date, "%b"),
          format(end_date, "%Y"))
}

# convert date to payroll/sector format: "july 2025"
make_payroll_label <- function(date) {
  format(date, "%B %Y")
}

#  convert date to sheet 13/15 format: "2000-01-01"
make_ymd_label <- function(date) {
  format(date, "%Y-%m-%d")
}

# convert date to cpi/hr1 format
make_datetime_label <- function(date) {
  paste0(format(date, "%Y-%m-%d"), " 00:00:00")
}

#  for  text: "june to august 2025"
lfs_label_narrative <- function(end_date) {
  start_date <- end_date %m-% months(2)
  sprintf("%s to %s",
          format(start_date, "%B %Y"),
          format(end_date, "%B %Y"))
}

#  lookup function

#  get value by dataset_identifier_code and time_period
val_by_code <- function(pg_data, code, period_label) {
  if (is.null(pg_data) || nrow(pg_data) == 0) return(NA_real_)
  
  match_row <- pg_data %>%
    filter(
      dataset_identifier_code == code,
      trimws(time_period) == trimws(period_label)
    )
  
  if (nrow(match_row) == 0) return(NA_real_)
  
  suppressWarnings(as.numeric(match_row$value[1]))
}

# formatting functions 

format_int <- function(x) {
  if (is.na(x)) return(NA_character_)
  v <- round(as.numeric(x), 0)
  if (is.na(v)) return(NA_character_)
  if (v == 0) return("0")
  paste0(ifelse(v > 0, "+", "-"), format(abs(v), big.mark = ","))
}

#  pp format
format_pp <- function(x) {
  if (is.na(x)) return(NA_character_)
  v <- as.numeric(x)
  if (is.na(v)) return(NA_character_)
  if (v == 0) return("0pp")

  # increase decimal places until we hit a significant digit (max 4)
  for (d in 1:4) {
    vr <- round(v, d)
    if (vr != 0) {
      return(paste0(ifelse(vr > 0, "+", "-"), format(abs(vr), nsmall = d), "pp"))
    }
  }
  # fallback: use original sign with 4 decimals
  paste0(ifelse(v > 0, "+", "-"), format(abs(round(v, 4)), nsmall = 4), "pp")
}

# increase decimals until significant digit appears (max 4)
format_pct1 <- function(x) {
  if (is.na(x)) return(NA_character_)
  v <- as.numeric(x)
  if (is.na(v)) return(NA_character_)
  if (v == 0) return("0%")

  for (d in 1:4) {
    vr <- round(v, d)
    if (vr != 0) {
      return(paste0(ifelse(vr > 0, "+", "-"), format(abs(vr), nsmall = d), "%"))
    }
  }
  paste0(ifelse(v > 0, "+", "-"), format(abs(round(v, 4)), nsmall = 4), "%")
}

format_gbp_signed0 <- function(x) {
  if (is.na(x)) return(NA_character_)
  v <- round(as.numeric(x), 0)
  if (is.na(v)) return(NA_character_)
  if (v == 0) return("£0")
  paste0(ifelse(v > 0, "+£", "-£"), format(abs(v), big.mark = ","))
}

# formatting functions 

format_int_unsigned <- function(x) {
  if (is.na(x)) return(NA_character_)
  v <- round(abs(as.numeric(x)), 0)
  if (is.na(v)) return(NA_character_)
  format(v, big.mark = ",")
}

# smart unsigned: increase decimals until significant (max 4)
format_pct1_unsigned <- function(x) {
  if (is.na(x)) return(NA_character_)
  v <- abs(as.numeric(x))
  if (is.na(v)) return(NA_character_)
  if (v == 0) return("0.0%")

  for (d in 1:4) {
    vr <- round(v, d)
    if (vr != 0) {
      return(paste0(format(vr, nsmall = d), "%"))
    }
  }
  paste0(format(round(v, 4), nsmall = 4), "%")
}

#  formatting functions decimal handling

fmt_pct <- function(x) {
  if (is.na(x)) return('—')
  if (x == 0) return('0.0%')
  for (d in 1:4) {
    vr <- round(x, d)
    if (vr != 0) return(paste0(format(vr, nsmall = d), '%'))
  }
  paste0(format(round(x, 4), nsmall = 4), '%')
}

fmt_pp <- function(x) {
  if (is.na(x)) return('—')
  v <- abs(x)
  if (v == 0) return('0.0 percentage points')
  for (d in 1:4) {
    vr <- round(v, d)
    if (vr != 0) return(paste0(format(vr, nsmall = d), ' percentage points'))
  }
  paste0(format(round(v, 4), nsmall = 4), ' percentage points')
}

fmt_dir <- function(x, up_word = 'up', down_word = 'down') {
  ifelse(is.na(x) || x == 0, '', ifelse(x > 0, up_word, down_word))
}

fmt_mill <- function(x) {
  ifelse(is.na(x), '—', paste0(format(round(x, 1), nsmall = 1)))
}

fmt_int <- function(x) {
  ifelse(is.na(x), '—', format(round(x, 0), big.mark = ','))
}

fmt_one_dec <- function(x) {
  if (is.na(x)) return("—")
  if (x == 0) return(format(0, nsmall = 1))
  for (d in 1:4) {
    vr <- round(x, d)
    if (vr != 0) return(format(vr, nsmall = d))
  }
  format(round(x, 4), nsmall = 4)
}
